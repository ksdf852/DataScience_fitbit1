import fitbit
import json
import ConfigParser

config = ConfigParser.RawConfigParser()
config.read('config.ini')

CLIENT_ID = config.get('ACCOUNT','CLIENT_ID')
CLIENT_SECRET = config.get('ACCOUNT','CLIENT_SECRET')
ACCESS_TOKEN = config.get('ACCOUNT','ACCESS_TOKEN')
REFRESH_TOKEN = config.get('ACCOUNT','REFRESH_TOKEN')

authd_client = fitbit.Fitbit(CLIENT_ID, CLIENT_SECRET, access_token=ACCESS_TOKEN, refresh_token= REFRESH_TOKEN)

week_step=[]
days=['2017-03-13','2017-03-14','2017-03-15','2017-03-16','2017-03-17','2017-03-18','2017-03-19','2017-03-20','2017-03-21','2017-03-22','2017-03-23','2017-03-24','2017-03-25','2017-03-26']
for i in range(14) :
	intraday_step = authd_client.intraday_time_series('activities/steps', base_date=days[i])

	week_step.append(intraday_step['activities-steps'])

print(week_step)

f=open('step2.json','w')
json.dump(week_step,f,encoding="UTF-8")
