import json
import datetime
import matplotlib.pyplot as plt
from datetime import datetime

json_file = "./step2.json"
result={}
def readConfig(filename):

	f = open(filename,'r')
	js = json.loads(f.read())
	f.close()
	return js

def main() : 
	global json_file
	global result

	result = readConfig(json_file)

	values=[]
	days=[]

	length=len(result)
	for i in range(length) :
		values.append(result[i][0]['value'].encode("utf-8"))

		days.append(datetime.strptime(result[i][0]['dateTime'],"%Y-%m-%d"))

	
	print(days)
	plt.plot(days,values)
	plt.xlabel("week")
	plt.ylabel("step")

	plt.show()
#	for i in repos :
#		print(i)
#		print(i['value'])
#		print(i['time'])
if __name__=="__main__" : 
	main()
