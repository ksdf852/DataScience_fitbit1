import json
import datetime
import matplotlib.pyplot as plt
from datetime import datetime
from datetime import time
json_file = "./step.json"
result={}
def readConfig(filename):

	f = open(filename,'r')
	js = json.loads(f.read())
	f.close()
	return js

def main() : 
	global json_file
	global result

	result = readConfig(json_file)

	values=[]
	times=[]

	length=len(result['activities-steps-intraday']['dataset'])
	for i in range(length) :
		values.append([result['activities-steps-intraday']['dataset'][i]['value']])

#		times = times + [result['activities-steps-intraday']['dataset'][i]['time'].encode("utf-8")]

		temp=result['activities-steps-intraday']['dataset'][i]['time']
		
		change=datetime(2017,03,26,int(temp[0]+temp[1]),int(temp[3]+temp[4]),int(temp[6]+temp[7]))
		times.append([change])
#		times[i].year=0


	print(times)
	plt.plot(times,values)
	plt.xlabel("time")
	plt.ylabel("step")
	plt.show()
if __name__=="__main__" : 
	main()
